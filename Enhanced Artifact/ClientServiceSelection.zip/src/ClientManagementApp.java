import javax.swing.*;
import java.awt.*;

/**
 * Primary class to launch the Application.
 */
public class ClientManagementApp {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainFrame window = new MainFrame(); // Create the application window
                window.frame.setVisible(true); // Make the window visible
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

/**
 * Class to handle the main application frame.
 * Uses a card layout to handle switching between different screens.
 */
class MainFrame {
    JFrame frame;
    JPanel cardPanel;
    CardLayout cardLayout;

    int loginCounter = 0; // Counter variable to track login attempts.
    final int attempts = 3; // Constant representing the number of login attempts allowed.

    // Arrays containing client names and their associated service selection by index
    String[] serviceSelections = {"Brokerage", "Retirement", "Brokerage", "Brokerage", "Retirement"};
    String[] clientNames = {"Bob Jones", "Sarah Davis", "Amy Friendly", "Johnny Smith", "Carol Spears"};

    /**
     * Constructor for MainFrame class.
     * Calls private initialization method.
     */
    public MainFrame() {
        initialize();
    }

    /**
     * Initializes the main frame and its components.
     * Includes the login and main panels
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 500, 500); // sets the size of the frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        frame.getContentPane().add(cardPanel, BorderLayout.CENTER);

        JPanel loginPanel = createLoginPanel(); // Create the login panel

        cardPanel.add(loginPanel, "login"); // Add the login panel to the card panel

        defineMainPanel(); // calls dedicated method to create the main panel and add it to the card panel

        cardLayout.show(cardPanel, "login"); // Show the login panel first.
    }

    /**
     * Creates and returns the login panel.
     *
     * @return the login panel
     */
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null); // use null layout

        // Login screen welcome/title label
        JLabel entryLabel = new JLabel("Client Portal Login");
        entryLabel.setBounds(100, 10, 150, 25); // Set the label position and size
        panel.add(entryLabel); // Add label to the panel

        // Username label
        JLabel userLabel = new JLabel("Username");
        userLabel.setBounds(35, 50, 100, 25); // Set the label position and size
        panel.add(userLabel); // Add label to the panel

        // Text field for username entry
        JTextField userText = new JTextField();
        userText.setBounds(125, 50, 150, 25); // Set the text field position and size
        panel.add(userText); // Add text field to the panel

        // Password label
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(35, 85, 100, 25); // Set the label position and size
        panel.add(passwordLabel); // Add label to the panel

        // Text field for password entry
        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(125, 85, 150, 25); // Set the password field position and size
        panel.add(passwordText); // Add text field to the panel

        // Feedback message for login success status
        JLabel successLabel = new JLabel("");
        successLabel.setBounds(35, 125, 250, 25); // Set the label position and size
        panel.add(successLabel); // Add label to the panel

        // Button used to initiate login attempt
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(100, 150, 100, 25); // Set the button position and size
        panel.add(loginButton); // Add button to the panel

        // Action listener for the login button, initiates credential validation
        loginButton.addActionListener(e -> {

            // TODO: Implement further input sanitization
            String username = userText.getText(); // Retrieve the username from the username text field
            String password = new String(passwordText.getPassword()); // Retrieve the password from the password text field
            successLabel.setText(""); // Clear the success label

            // Validate user input against admin username and password
            // TODO: Implement salt and hashing methods to avoid storing a plain text password
            if (username.equals("admin") && password.equals("123")) {

                // If login is successful, transition to the main panel
                successLabel.setText("Login Successful");
                cardLayout.show(cardPanel, "main");
            } else {

                // If login is unsuccessful, increment the login counter
                loginCounter++;

                // If the user expends their login attempts, disable Login button
                if (loginCounter == attempts) {
                    loginButton.setEnabled(false);
                }

                // Print success state message to inform the user of failed login.
                successLabel.setText("Login Failed, " + (attempts - loginCounter) + " attempts remaining.");

            }
        });
        return panel;
    }

    /**
     * Creates and returns the main panel displaying client names and their service selections.
     * Includes edit buttons for each client to make changes to their selected service.
     * @return the main panel
     */
    private JPanel createMainPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null); // use null layout

        // Client Name column label
        JLabel categoryOneLabel = new JLabel("Client Name");
        categoryOneLabel.setBounds(35, 10, 100, 25); // Set the label position and size
        panel.add(categoryOneLabel); // Add label to the panel

        // Service Selected column label
        JLabel categoryTwoLabel = new JLabel("Service Selected");
        categoryTwoLabel.setBounds(150, 10, 100, 25); // Set the label position and size
        panel.add(categoryTwoLabel); // Add label to the panel


        // Name label for the first client
        JLabel clientOneNameLabel = new JLabel(clientNames[0]);
        clientOneNameLabel.setBounds(35, 50, 100, 25); // Set the label position and size
        panel.add(clientOneNameLabel); // Add label to the panel

        // Service label for the first client
        JLabel clientOneServiceLabel = new JLabel(serviceSelections[0]);
        clientOneServiceLabel.setBounds(150, 50, 100, 25); // Set the label position and size
        panel.add(clientOneServiceLabel); // Add label to the panel

        // Edit button for the first client
        JButton clientOneButton = new JButton("Edit");
        clientOneButton.setBounds(265, 50, 75, 25); // Set the button position and size
        panel.add(clientOneButton); // Add button to the panel

        // On clicking the button, update the Edit Service Panel with the index of the client
        clientOneButton.addActionListener(e -> {
            updateEditServicePanel(0);
            cardLayout.show(cardPanel, "editService"); // Transition to Edit Service panel
        });


        // Name label for the second client
        JLabel clientTwoNameLabel = new JLabel(clientNames[1]);
        clientTwoNameLabel.setBounds(35, 85, 100, 25); // Set the label position and size
        panel.add(clientTwoNameLabel); // Add label to the panel

        // Service label for the second client
        JLabel clientTwoServiceLabel = new JLabel(serviceSelections[1]);
        clientTwoServiceLabel.setBounds(150, 85, 100, 25); // Set the label position and size
        panel.add(clientTwoServiceLabel); // Add label to the panel

        // Edit button for the second client
        JButton clientTwoButton = new JButton("Edit");
        clientTwoButton.setBounds(265, 85, 75, 25); // Set the button position and size
        panel.add(clientTwoButton); // Add button to the panel

        // On clicking the button, update the Edit Service Panel with the index of the client
        clientTwoButton.addActionListener(e -> {
            updateEditServicePanel(1);
            cardLayout.show(cardPanel, "editService"); // Transition to Edit Service panel
        });


        // Name label for the third client
        JLabel clientThreeNameLabel = new JLabel(clientNames[2]);
        clientThreeNameLabel.setBounds(35, 120, 100, 25); // Set the label position and size
        panel.add(clientThreeNameLabel); // Add label to the panel

        // Service label for the third client
        JLabel clientThreeServiceLabel = new JLabel(serviceSelections[2]);
        clientThreeServiceLabel.setBounds(150, 120, 100, 25); // Set the label position and size
        panel.add(clientThreeServiceLabel); // Add label to the panel

        // Edit button for the third client
        JButton clientThreeButton = new JButton("Edit");
        clientThreeButton.setBounds(265, 120, 75, 25); // Set the button position and size
        panel.add(clientThreeButton); // Add button to the panel

        // On clicking the button, update the Edit Service Panel with the index of the client
        clientThreeButton.addActionListener(e -> {
            updateEditServicePanel(2);
            cardLayout.show(cardPanel, "editService"); // Transition to Edit Service panel
        });


        // Name label for the fourth client
        JLabel clientFourNameLabel = new JLabel(clientNames[3]);
        clientFourNameLabel.setBounds(35, 155, 100, 25); // Set the label position and size
        panel.add(clientFourNameLabel); // Add label to the panel

        // Service label for the fourth client
        JLabel clientFourServiceLabel = new JLabel(serviceSelections[3]);
        clientFourServiceLabel.setBounds(150, 155, 100, 25); // Set the label position and size
        panel.add(clientFourServiceLabel); // Add label to the panel

        // Edit button for the fourth client
        JButton clientFourButton = new JButton("Edit");
        clientFourButton.setBounds(265, 155, 75, 25); // Set the button position and size
        panel.add(clientFourButton); // Add button to the panel

        // On clicking the button, update the Edit Service Panel with the index of the client
        clientFourButton.addActionListener(e -> {
            updateEditServicePanel(3);
            cardLayout.show(cardPanel, "editService"); // Transition to Edit Service panel
        });


        // Name label for the fifth client
        JLabel clientFiveNameLabel = new JLabel(clientNames[4]);
        clientFiveNameLabel.setBounds(35, 190, 100, 25); // Set the label position and size
        panel.add(clientFiveNameLabel); // Add label to the panel

        // Service label for the fifth client
        JLabel clientFiveServiceLabel = new JLabel(serviceSelections[4]);
        clientFiveServiceLabel.setBounds(150, 190, 100, 25); // Set the label position and size
        panel.add(clientFiveServiceLabel); // Add label to the panel

        // Edit button for the fifth client
        JButton clientFiveButton = new JButton("Edit");
        clientFiveButton.setBounds(265, 190, 75, 25); // Set the button position and size
        panel.add(clientFiveButton); // Add button to the panel

        // On clicking the button, update the Edit Service Panel with the index of the client
        clientFiveButton.addActionListener(e -> {
            updateEditServicePanel(4);
            cardLayout.show(cardPanel, "editService"); // Transition to Edit Service panel
        });

        return panel;
    }

    /**
     * Prepares the main panel.
     */
    private void defineMainPanel() {
        JPanel mainPanel = createMainPanel(); // Create the main panel
        cardPanel.add(mainPanel, "main"); // Add the main panel to the card panel
    }

    /**
     * Refreshes the main panel to reflect client service changes.
     */
    private void refreshMainPanel() {
        cardPanel.remove(cardPanel.getComponent(1)); // Remove the old main panel
        defineMainPanel(); // Add the updated main panel
    }

    /**
     * Updates the edit service panel for a given client.
     *
     * @param client the index of the client to be edited
     */
    private void updateEditServicePanel(int client) {
        JPanel editServicePanel = createEditServicePanel(client); // Create the edit service panel
        cardPanel.add(editServicePanel, "editService"); // Add the edit service panel to the card panel
    }

    /**
     * Creates and returns the edit service panel for a given client.
     *
     * @param client the index of the client to be edited
     * @return the edit service panel
     */
    private JPanel createEditServicePanel(int client) {
        JPanel panel = new JPanel();
        panel.setLayout(null); // Use null layout

        // User prompt label
        JLabel clientNameLabel = new JLabel("Select service option for " + clientNames[client]);
        clientNameLabel.setBounds(35, 50, 250, 25); // Set the label position and size
        panel.add(clientNameLabel); // Add label to the panel

        // Brokerage service option button
        JButton brokerageButton = new JButton("Brokerage");
        brokerageButton.setBounds(35, 85, 100, 25); // Set the button position and size
        panel.add(brokerageButton); // Add button to the panel

        // On clicking the button, update the service choice of the set client
        brokerageButton.addActionListener(e -> {
            serviceSelections[client] = "Brokerage";
            refreshMainPanel(); // refresh main panel to reflect edits
            cardLayout.show(cardPanel, "main"); // Transition back to main panel
        });

        // Retirement service option button
        JButton retirementButton = new JButton("Retirement");
        retirementButton.setBounds(35, 120, 100, 25); // Set the button position and size
        panel.add(retirementButton);// Add button to the panel

        // On clicking the button, update the service choice of the set client
        retirementButton.addActionListener(e -> {
            serviceSelections[client] = "Retirement";
            refreshMainPanel(); // refresh main panel to reflect edits
            cardLayout.show(cardPanel, "main"); // Transition back to main panel
        });

        return panel;
    }
}